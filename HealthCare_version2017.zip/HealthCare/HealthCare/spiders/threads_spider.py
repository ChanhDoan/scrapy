import scrapy, csv
import os
from bs4 import BeautifulSoup
import re
import urllib
from HealthCare.items import HealthcareItem
from scrapy.crawler import CrawlerProcess


class ThreadsSpider(scrapy.Spider):
    
    name = "HealthCare"
    #start_urls = ['https://q1medicare.com/PartD-SearchPDPMedicare-2019PlanFinder.php#results',    ]

    #2019
    #start_urls=['https://q1medicare.com/PartD-SearchPDPMedicare-2019PlanFinder.php?utm_source=partd&utm_medium=jumplink&utm_campaign=header',]
    
    #2018
    #start_urls=['https://q1medicare.com/PartD-SearchPDPMedicare-2018PlanFinder.php', ]

    #2017
    start_urls=['https://q1medicare.com/PartD-SearchPDPMedicare-2017PlanFinder.php', ]

    #start_urls=['https://q1medicare.com/PartD-SearchPDPMedicare-2019PlanFinder.php?state=CT#results', ]

    outfile = open("PlanID2017.csv", "w", newline="")
    writer = csv.writer(outfile)
    number_row =0
    

    def parse(self, response):
        
        #i=0

        #2019
        # self.writer.writerow(['Year', 'Plan_ID' ,  'Plan_Name' ,  'Organiztion_Marketing' ,  'State' ,  'Type' ,  'Plan_Type' ,  'Monthly' ,  'Annual' ,  'Total_Drugs' ,  'Tier_1' ,  'Tier_2' ,  'Tier_3' ,  'Tier_4' ,  'Tier_5' ,  'Number_Member' , 'Region' ,  'Number_Member_CMS' ,  'Number_Member_National' ,  'Overall_Star_Rating' ,'Summary_Rating_of_Prescription_Drug_Plan_Quality',  'Customer_Service_Rating' ,  'Call_Center_Foreign_Language_Interpreter_and_TTY_Availability' ,  'Drug_Plan_Makes_Timely_Decisions_about_Appeals' ,  'Fairness_of_Drug_Plans_Appeal_Decisions' ,  'Member_Complaints_and_Changes' ,  'Complaints_about_the_Drug_Plan' ,  'Members_Choosing_to_Leave_the_Plan' ,  'Improvement' ,  'Member_Experience_Rating' ,  'Members_Rating_of_Drug_Plan' ,  'Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan' ,  'Drug_Cost_Accuracy_Rating' ,  'Medicare_gov_Plan_Finder_Drug_Price_Accuracy' ,  'Medication_Adherence_for_Diabetes_Medications' ,  'Medication_Adherence_for_Hypertension_RAS_antagonists' ,  'Medication_Adherence_for_Cholesterol_Statins' ,  'MTM_Program_Completion_Rate_for_CMR' ,  'Statin_Use_in_Persons_with_Diabetes'  ])
        # yield{'Year':'Year',	'Plan_ID': 'Plan_ID' ,	'Plan_Name': 'Plan_Name' ,	'Organiztion Marketing': 'Organiztion_Marketing' , 'State': 'State' ,	'Type': 'Type' ,	'Plan_Type': 'Plan_Type' ,	'Monthly': 'Monthly' ,	'Annual': 'Annual' ,	'Total_Drugs': 'Total_Drugs' ,	'Tier 1': 'Tier_1' , 'Tier 2': 'Tier_2' ,	'Tier 3': 'Tier_3' ,	'Tier 4': 'Tier_4' ,	'Tier 5 ': 'Tier_5' ,	'Number_ Member': 'Number_Member' , 'Region': 'Region' ,'Number_Member_CMS': 'Number_Member_CMS' ,	'Number_ Member_National': 'Number_Member_National' ,	'Overall_Star_Rating': 'Overall_Star_Rating' ,'Summary_Rating_of_Prescription_Drug_Plan_Quality':'Summary_Rating_of_Prescription_Drug_Plan_Quality',	'Customer_Service_Rating': 'Customer_Service_Rating' ,	'Call Center — Foreign Language Interpreter and TTY Availability': 'Call_Center_Foreign_Language_Interpreter_and_TTY_Availability' ,	'Drug Plan Makes Timely Decisions about Appeals': 'Drug_Plan_Makes_Timely_Decisions_about_Appeals' ,	'Fairness of Drug Plan’s Appeal Decisions': 'Fairness_of_Drug_Plans_Appeal_Decisions' ,	'Member Complaints and Changes': 'Member_Complaints_and_Changes' , 'Complaints about the Drug Plan (higher score is better - means fewer complaints)': 'Complaints_about_the_Drug_Plan' ,	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)': 'Members_Choosing_to_Leave_the_Plan'  ,'Improvement (if any) in the Drug Plans Performance': 'Improvement' ,	'Member_Experience_Rating': 'Member_Experience_Rating' ,	'Members’s Rating of Drug Plan': 'Members_Rating_of_Drug_Plan' ,	'Ease of Getting Prescriptions Filled When Using the Plan': 'Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan' ,	'Drug_Cost_Accuracy_Rating': 'Drug_Cost_Accuracy_Rating' ,	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)': 'Medicare_gov_Plan_Finder_Drug_Price_Accuracy' ,	'Medication Adherence for Diabetes Medications': 'Medication_Adherence_for_Diabetes_Medications' ,	'Medication Adherence for Hypertension (RAS antagonists)': 'Medication_Adherence_for_Hypertension_RAS_antagonists' ,	'Medication Adherence for Cholesterol (Statins)': 'Medication_Adherence_for_Cholesterol_Statins' ,	'MTM Program Completion Rate for CMR': 'MTM_Program_Completion_Rate_for_CMR' ,	'Statin Use in Persons with Diabetes': 'Statin_Use_in_Persons_with_Diabetes' }

        #2018
        # self.writer.writerow(['Year', 'Plan_ID' ,  'Plan_Name' ,  'Organiztion_Marketing' ,  'State' ,  'Type' ,  'Plan_Type' ,  'Monthly' ,  'Annual' ,  'Total_Drugs' ,  'Tier_1' ,  'Tier_2' ,  'Tier_3' ,  'Tier_4' ,  'Tier_5' ,  'Number_Member' , 'Region' ,  'Number_Member_CMS' ,  'Number_Member_National' ,  'Overall_Star_Rating' ,'Summary_Rating_of_Prescription_Drug_Plan_Quality',  'Customer_Service_Rating' ,  'Call_Center_Foreign_Language_Interpreter_and_TTY_Availability' ,  'Drug_Plan_Makes_Timely_Decisions_about_Appeals' ,  'Fairness_of_Drug_Plans_Appeal_Decisions' ,  'Member_Complaints_and_Changes' ,  'Complaints_about_the_Drug_Plan' ,  'Members_Choosing_to_Leave_the_Plan' , 'Beneficiary_Access_and_Performance_Problems', 'Improvement' ,  'Member_Experience_Rating' ,  'Members_Rating_of_Drug_Plan' ,  'Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan' ,  'Drug_Cost_Accuracy_Rating' ,  'Medicare_gov_Plan_Finder_Drug_Price_Accuracy' ,  'Medication_Adherence_for_Diabetes_Medications' ,  'Medication_Adherence_for_Hypertension_RAS_antagonists' ,  'Medication_Adherence_for_Cholesterol_Statins' ,  'MTM_Program_Completion_Rate_for_CMR'   ])
        # yield{'Year':'Year'	,'Plan_ID': 'Plan_ID' ,	'Plan_Name': 'Plan_Name' ,	'Organiztion Marketing': 'Organiztion_Marketing' , 'State': 'State' ,	'Type': 'Type' ,	'Plan_Type': 'Plan_Type' ,	'Monthly': 'Monthly' ,	'Annual': 'Annual' ,	'Total_Drugs': 'Total_Drugs' ,	'Tier 1': 'Tier_1' , 'Tier 2': 'Tier_2' ,	'Tier 3': 'Tier_3' ,	'Tier 4': 'Tier_4' ,	'Tier 5 ': 'Tier_5' ,	'Number_ Member': 'Number_Member' , 'Region': 'Region' ,'Number_Member_CMS': 'Number_Member_CMS' ,	'Number_ Member_National': 'Number_Member_National' ,	'Overall_Star_Rating': 'Overall_Star_Rating' ,'Summary_Rating_of_Prescription_Drug_Plan_Quality':'Summary_Rating_of_Prescription_Drug_Plan_Quality',	'Customer_Service_Rating': 'Customer_Service_Rating' ,	'Call Center — Foreign Language Interpreter and TTY Availability': 'Call_Center_Foreign_Language_Interpreter_and_TTY_Availability' ,	'Drug Plan Makes Timely Decisions about Appeals': 'Drug_Plan_Makes_Timely_Decisions_about_Appeals' ,	'Fairness of Drug Plan’s Appeal Decisions': 'Fairness_of_Drug_Plans_Appeal_Decisions' ,	'Member Complaints and Changes': 'Member_Complaints_and_Changes' , 'Complaints about the Drug Plan (higher score is better - means fewer complaints)': 'Complaints_about_the_Drug_Plan' ,	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)': 'Members_Choosing_to_Leave_the_Plan' ,	'Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems)':'Beneficiary_Access_and_Performance_Problems','Improvement (if any) in the Drug Plans Performance': 'Improvement' ,	'Member_Experience_Rating': 'Member_Experience_Rating' ,	'Members’s Rating of Drug Plan': 'Members_Rating_of_Drug_Plan' ,	'Ease of Getting Prescriptions Filled When Using the Plan': 'Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan' ,	'Drug_Cost_Accuracy_Rating': 'Drug_Cost_Accuracy_Rating' ,	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)': 'Medicare_gov_Plan_Finder_Drug_Price_Accuracy' ,	'Medication Adherence for Diabetes Medications': 'Medication_Adherence_for_Diabetes_Medications' ,	'Medication Adherence for Hypertension (RAS antagonists)': 'Medication_Adherence_for_Hypertension_RAS_antagonists' ,	'Medication Adherence for Cholesterol (Statins)': 'Medication_Adherence_for_Cholesterol_Statins' ,	'MTM Program Completion Rate for CMR': 'MTM_Program_Completion_Rate_for_CMR' }


        #2017
        self.writer.writerow(['Year', 'Plan_ID' ,  'Plan_Name' ,  'Organiztion_Marketing' ,  'State' ,  'Type' ,  'Plan_Type' ,  'Monthly' ,  'Annual' ,  'Total_Drugs' ,  'Tier_1' ,  'Tier_2' ,  'Tier_3' ,  'Tier_4' ,  'Tier_5' ,  'Number_Member' , 'Region' ,  'Number_Member_CMS' ,  'Number_Member_National' ,  'Overall_Star_Rating' ,'Summary_Rating_of_Prescription_Drug_Plan_Quality',  'Customer_Service_Rating' ,  'Call_Center_Foreign_Language_Interpreter_and_TTY_Availability' ,  'Drug_Plan_Makes_Timely_Decisions_about_Appeals' ,  'Fairness_of_Drug_Plans_Appeal_Decisions' ,  'Member_Complaints_and_Changes' ,  'Complaints_about_the_Drug_Plan' ,  'Members_Choosing_to_Leave_the_Plan' , 'Beneficiary_Access_and_Performance_Problems', 'Improvement' ,  'Member_Experience_Rating' ,  'Members_Rating_of_Drug_Plan' ,  'Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan' ,  'Drug_Cost_Accuracy_Rating' ,  'Medicare_gov_Plan_Finder_Drug_Price_Accuracy' ,'High_Risk_Medication',  'Medication_Adherence_for_Diabetes_Medications' ,  'Medication_Adherence_for_Hypertension_RAS_antagonists' ,  'Medication_Adherence_for_Cholesterol_Statins' ,  'MTM_Program_Completion_Rate_for_CMR'   ])
        yield{'Year':'Year'	,'Plan_ID': 'Plan_ID' ,	'Plan_Name': 'Plan_Name' ,	'Organiztion Marketing': 'Organiztion_Marketing' , 'State': 'State' ,	'Type': 'Type' ,	'Plan_Type': 'Plan_Type' ,	'Monthly': 'Monthly' ,	'Annual': 'Annual' ,	'Total_Drugs': 'Total_Drugs' ,	'Tier 1': 'Tier_1' , 'Tier 2': 'Tier_2' ,	'Tier 3': 'Tier_3' ,	'Tier 4': 'Tier_4' ,	'Tier 5 ': 'Tier_5' ,	'Number_ Member': 'Number_Member' , 'Region': 'Region' ,'Number_Member_CMS': 'Number_Member_CMS' ,	'Number_ Member_National': 'Number_Member_National' ,	'Overall_Star_Rating': 'Overall_Star_Rating' ,'Summary_Rating_of_Prescription_Drug_Plan_Quality':'Summary_Rating_of_Prescription_Drug_Plan_Quality',	'Customer_Service_Rating': 'Customer_Service_Rating' ,	'Call Center — Foreign Language Interpreter and TTY Availability': 'Call_Center_Foreign_Language_Interpreter_and_TTY_Availability' ,	'Drug Plan Makes Timely Decisions about Appeals': 'Drug_Plan_Makes_Timely_Decisions_about_Appeals' ,	'Fairness of Drug Plan’s Appeal Decisions': 'Fairness_of_Drug_Plans_Appeal_Decisions' ,	'Member Complaints and Changes': 'Member_Complaints_and_Changes' , 'Complaints about the Drug Plan (higher score is better - means fewer complaints)': 'Complaints_about_the_Drug_Plan' ,	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)': 'Members_Choosing_to_Leave_the_Plan' ,	'Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems)':'Beneficiary_Access_and_Performance_Problems','Improvement (if any) in the Drug Plans Performance': 'Improvement' ,	'Member_Experience_Rating': 'Member_Experience_Rating' ,	'Members’s Rating of Drug Plan': 'Members_Rating_of_Drug_Plan' ,	'Ease of Getting Prescriptions Filled When Using the Plan': 'Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan' ,	'Drug_Cost_Accuracy_Rating': 'Drug_Cost_Accuracy_Rating' ,	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)': 'Medicare_gov_Plan_Finder_Drug_Price_Accuracy' ,'High Risk Medication':'High_Risk_Medication',	'Medication Adherence for Diabetes Medications': 'Medication_Adherence_for_Diabetes_Medications' ,	'Medication Adherence for Hypertension (RAS antagonists)': 'Medication_Adherence_for_Hypertension_RAS_antagonists' ,	'Medication Adherence for Cholesterol (Statins)': 'Medication_Adherence_for_Cholesterol_Statins' ,	'MTM Program Completion Rate for CMR': 'MTM_Program_Completion_Rate_for_CMR' }

        for href in response.css('div.w3-row span.text div a.textgroup::attr(href)').getall():
            #self.writer.writerow([' ', href ,  ' ' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' , '' ,  '' ,  '' ,  '' ,'',  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' , '', '' ,  '' ,  '' ,  '' ,  '' ,  '' ,'',  '' ,  '' ,  '' ,  ''   ])
            yield scrapy.Request(href, callback=self.getState)

        
    def close(self):
        self.outfile.close()
        print("-----Check to see if this is closed-----")

    #get list of link of State
    def getState(self, response):
        
        urls=[]
        
        ############################################################################
        #############2018 and 2019
        # i=0
        # for href in response.css('tr.tbldark a.teasertext::attr(href)').getall():
        #     if i%2==0:
        #         urls.append(href)
        #         #self.getInformation(href,row)
        #         #print(i, href)
        #     i=i+1
        # for href in response.css('tr.tbllight a.teasertext::attr(href)').getall():
        #     if i%2==0:
        #         urls.append(href)
        #         #self.getInformation(href,row)
        #         #print(i, href)
        #     i=i+1
        # for i in urls:
        #     yield scrapy.Request(i, callback=self.getInformation)
        ############################################################################

        ############################################################################
        #############2017
        ## Dem tong so dong du lieu cua Plan D trong 1 nam
        number = response.css('div.resultchart table.chart caption strong span.tblhighlight::text').getall()
        # #if number is None:
        # self.number_row = self.number_row + int(number[0])
        #self.writer.writerow([' ', number ,  ' ' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' , '' ,  '' ,  '' ,  '' ,'',  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' , '', '' ,  '' ,  '' ,  '' ,  '' ,  '' ,'',  '' ,  '' ,  '' ,  ''   ])


        i=0
        for href in response.css('tr.tbldark td a.teasertext::attr(href)').getall():
            if i%2==0:
                urls.append(href)

            i=i+1
        for href in response.css('tr.tbllight td a.teasertext::attr(href)').getall():
            if i%2==0:
                urls.append(href)

            i=i+1
        for j in urls:
            #self.writer.writerow([' ', j ,  ' ' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' , '' ,  '' ,  '' ,  '' ,'',  '' ,  '' ,  '' ,  '' ,  '' ,  '' ,  '' , '', '' ,  '' ,  '' ,  '' ,  '' ,  '' ,'',  '' ,  '' ,  '' ,  ''   ])
            yield scrapy.Request(j, callback=self.getInformation)
        ############################################################################
            

    #Information of each plan ID
    #Get information state
    #start_urls = ['https://q1medicare.com/PartD-2019-MedicarePDPDrugPlanBenefits.php?state=CT&source=2019PDPFinder&contractId=S4802&planId=137&plan=WellCare%20Value%20Script%20(PDP)%20-%20S4802-137&utm_source=partd&utm_medium=pdpfinder&utm_campaign=planname', ]
    def getInformation(self, response):

        ####################################################################
        
        # Tra ve gan du cac noi dung 
        #item = response.meta['item']
        item = HealthcareItem()
        resource=[]
        i=0
        for content in response.css('tr.tbllight td::text ').getall():
            #print(i, content)
            i = i+1
            resource.append(content.strip())
        item['Plan_ID'] = resource[3]
        item['Plan_Name'] = resource[0].split("(PDP)")[0]
        Organiztion_Marketing = resource[1].split("by")
        item['Organiztion_Marketing'] = Organiztion_Marketing[-1]
        item['State'] = resource[2]
        type = resource[0].split(" ")[-1]
        type=type.strip(")")
        item['Type'] = type.strip("(")

        
        item['Monthly'] = resource[7].split(" (")[0]

        item['Annual'] = resource[8].split(" (")[0]
        item['Total_Drugs'] =	resource[12].split(" drugs")[0]

        item['Tier_1'] = resource[23]
        item['Tier_2'] = resource[24]
        item['Tier_3'] = resource[25]
        item['Tier_4'] = resource[26]		
        item['Tier_5'] = resource[27]	
        #Truong hop 1
        # 27: '555'
        # 28: 'National Plan'
        # 29:'131 members'
        # 30: '4074 members ('
        # 31: ')'
        
        #Truong hop 2
        # 27: '555'
        # 28: 'National Plan'
        # 29: '4074 members ('
        # 30: ')'
        # 31: '1,884,531 members'

        # Truong Hop 3
        # 27: '555'
        # 28: 'Yes
        # 29: 'National Plan'
        # 30:'131 members'
        # 31: '4074 members ('
        # 32: ')'
        # 33: '2,818,114 members'

        # Truong hop 4
        # 27: '555'
        # 28: 'Yes'
        # 29: 'National Plan'
        # 30: '4074 members ('
        # 31: ')'

        
        # Truong hop 5
        # 27: 'Yes'
        # 28: 'National Plan'
        # 29: '131 members'
        # 30: '4074 members ('
        # 31: ')'

        # Truong hop 6
        # 27: 'Yes'
        # 28: 'National Plan'
        # 29: '4074 members ('
        # 30: ')'
        # 31: '2,818,114 members'

        if resource[27] == "Yes":
            item['Tier_5'] = 0
            item['Plan_Type'] = resource[28]
            if resource[30]==")":
                # Truong hop 6
                item['Number_Member']=0	
                #row['Region']=resource[]
                
                item['Number_Member_CMS']=	resource[29].split("members")[0]	
                item['Number_Member_National']=	resource[31].split("members")[0]
            else:
                # Truong hop 5
                item['Number_Member']=resource[29].split("members")[0]
                #row['Region']=resource[]
                item['Number_Member_CMS']=	resource[30].split("members")[0]	
                item['Number_Member_National']=	resource[32].split("members")[0]
        if resource[28] == "Yes":
            item['Plan_Type'] = resource[29]
            if resource[31]==")":
                # Truong Hop 3
                item['Number_Member']=0	
                #row['Region']=resource[]
                
                item['Number_Member_CMS']=	resource[30].split("members")[0]	
                item['Number_Member_National']=	resource[32].split("members")[0]
            else:
                # Truong hop 4
                item['Number_Member']=resource[30].split("members")[0]
                #row['Region']=resource[]
                item['Number_Member_CMS']=	resource[31].split("members")[0]	
                item['Number_Member_National']=	resource[33].split("members")[0]
        else:
            item['Plan_Type'] = resource[28]
            if resource[30]==")":
                #Truong hop 2
                item['Number_Member']=0	
                #row['Region']=resource[]
                item['Number_Member_CMS']=	resource[29].split("members")[0]	
                item['Number_Member_National']=	resource[31].split("members")[0]
            if resource[31]==")":
                #Truong hop 1
                item['Number_Member']=resource[29].split("members")[0]	
                #row['Region']=resource[]
                item['Number_Member_CMS']=	resource[30].split("members")[0]	
                item['Number_Member_National']=	resource[32].split("members")[0]
            # else:
            #     item['Number_Member']=resource[29].split("members")[0]
            #     #row['Region']=resource[]
            #     item['Number_Member_CMS']=	resource[30].split("members")[0]	
            #     item['Number_Member_National']=	resource[32].split("members")[0]

        #Click to see other plans
        #Browse the WellCare Value Script (PDP) Formulary
        #CMS Region 02
        region=[]
        for content in response.css('tr.tbllight td a.textred b::text ').getall():
            #print(content)
            region.append(content.strip())
        item['Region']=region[2].split(" ")[-1]

        # print("\n\n dong dang test ")
        # for content in response.css('tr.tbllight td a.textred::text ').getall():
        #     print(content)
       
        # follow link rating 
        # kiem tra neu len=4 thi rating nay trong, khong cos link sang trang 
        link=[]

        for content in response.css('tr.tbllight td a.textred::attr(href) ').getall():
            #print(content)
            link.append(content)
        
        if link.__len__()>4:
            next_url=link[4]
            #item = self.getStar(next_url)
            request = scrapy.Request(next_url, callback=self.getStar)
            request.meta['item'] = item #By calling .meta, we can pass our item object into the callback.
            yield request #Return the item + Rating back to the parser.
                       
        else:
            item['Overall_Star_Rating'] = 0

            item['Summary_Rating_of_Prescription_Drug_Plan_Quality'] = 0

            item['Customer_Service_Rating']=	0
            item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'] =	0	
            
            item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'] = 0
            item['Fairness_of_Drug_Plans_Appeal_Decisions']=		0
            item['Member_Complaints_and_Changes'] = 0
            
            item['Complaints_about_the_Drug_Plan'] = 0
            item['Members_Choosing_to_Leave_the_Plan'] = 0
            ##################
            #2018, 2017
            #Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems)
            item['Beneficiary_Access_and_Performance_Problems']=0
            ##################
            item['Improvement']=0
            
            item['Member_Experience_Rating']=0
            item['Members_Rating_of_Drug_Plan']= 0
            item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan']=0
            
            item['Drug_Cost_Accuracy_Rating']= 0
            item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy']=	0	
            ##################
            #2017
            item['High_Risk_Medication']=	0
            ##################
            item['Medication_Adherence_for_Diabetes_Medications']=	0
            item['Medication_Adherence_for_Hypertension_RAS_antagonists']=	0
            item['Medication_Adherence_for_Cholesterol_Statins']=0
            item['MTM_Program_Completion_Rate_for_CMR']=	0

            ##################
            #2019 
            #item['Statin_Use_in_Persons_with_Diabetes']=0
            ##################

            #2019
            #year=2019
            # self.writer.writerow([year, item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Overall_Star_Rating'],'Summary_Rating_of_Prescription_Drug_Plan_Quality', item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan'], item['Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item['MTM_Program_Completion_Rate_for_CMR'], item['Statin_Use_in_Persons_with_Diabetes']])
            # yield{'Year':year,	'Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Overall_Star_Rating':item['Overall_Star_Rating'],'Summary_Rating_of_Prescription_Drug_Plan_Quality':'Summary_Rating_of_Prescription_Drug_Plan_Quality',	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions':item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR'],	'Statin Use in Persons with Diabetes':item['Statin_Use_in_Persons_with_Diabetes']}

            #2018
            # year=2018
            # self.writer.writerow([year, item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Overall_Star_Rating'],'Summary_Rating_of_Prescription_Drug_Plan_Quality', item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan'],item['Beneficiary_Access_and_Performance_Problems'], item['Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item['MTM_Program_Completion_Rate_for_CMR']])
            # yield{'Year':year,	'Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Overall_Star_Rating':item['Overall_Star_Rating'],'Summary_Rating_of_Prescription_Drug_Plan_Quality':'Summary_Rating_of_Prescription_Drug_Plan_Quality',	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions':item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],'Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems)':item['Beneficiary_Access_and_Performance_Problems'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR']}

            #2017
            year=2017
            self.writer.writerow([year, item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Overall_Star_Rating'], item['Summary_Rating_of_Prescription_Drug_Plan_Quality'], item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan'],item['Beneficiary_Access_and_Performance_Problems'], item['Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],item['High_Risk_Medication'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item['MTM_Program_Completion_Rate_for_CMR']])
            #yield{'Year':year,	'Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Overall_Star_Rating':item['Overall_Star_Rating'],'Summary_Rating_of_Prescription_Drug_Plan_Quality':item['Summary_Rating_of_Prescription_Drug_Plan_Quality'],	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions':item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],'Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems)':item['Beneficiary_Access_and_Performance_Problems'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],'High Risk Medication':item['High_Risk_Medication'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR']}

            yield item
               
        ###################################################################

    def getStar(self, response):
                
        ########
        item = response.meta['item']
        #item = HealthcareItem()
        star=[]

        content = response.css('tr.tblbluehdr th big::text').getall()
        star.append(content)
        #print(content)

        content=response.css('tr.tblbluehdr td b::text').getall()
        #print(content)
        star.append(content)

        for content in response.css('tr.tblhighlight td b::text ').getall():
            #print(content)
            star.append(content.strip())
        # list of star rating names
        #for content in response.css('tr td ul li::text ').getall():
        #    print(content)
        #print(response.css('tr td ul li::text ').getall())
        for content in response.css('tr.tblhighlightlight td b::text ').getall():
            #print(content)
            star.append(content.strip())
        for content in response.css('tr.tblnuetral td b::text ').getall():
            #print(content)
            star.append(content.strip())

        # list star rating 
        for content in response.css('tr.tbllight td::text ').getall():
            #print(content)
            star.append(content.strip())
        # print("\n\n")
        # count=0
        # for i in star:
        #     #print(count, i)
        #     count=count+1
        # print("\n\n")
        
        #########################################################################3
        #2017

        item['Overall_Star_Rating']=star[7]
        
        ## dang check
        
        item['Summary_Rating_of_Prescription_Drug_Plan_Quality']=star[10]

        item['Customer_Service_Rating']=	star[13]
        item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability']=	star[24]	
        item['Drug_Plan_Makes_Timely_Decisions_about_Appeals']=star[26]
        item['Fairness_of_Drug_Plans_Appeal_Decisions']= star[28]
        
        item['Member_Complaints_and_Changes']=star[16]
        item['Complaints_about_the_Drug_Plan']=star[30]
        item['Members_Choosing_to_Leave_the_Plan']=	star[32]
        item['Beneficiary_Access_and_Performance_Problems']=star[34]
        #########################################################################3
        #2017
        item['Improvement']=star[36]
        
        item['Member_Experience_Rating']=star[19]
        item['Members_Rating_of_Drug_Plan']= star[38]
        item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan']=star[40]
        
        item['Drug_Cost_Accuracy_Rating']= star[22]
        item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy']=	star[42]
        item['High_Risk_Medication']=star[44]
        item['Medication_Adherence_for_Diabetes_Medications']=	star[46]
        item['Medication_Adherence_for_Hypertension_RAS_antagonists']=	star[48]
        item['Medication_Adherence_for_Cholesterol_Statins']=star[50]
        item['MTM_Program_Completion_Rate_for_CMR']=	star[52]

        # #########################################################################3
        # #2018, 2019

        # item['Overall_Star_Rating']=star[10]
        
        # ## dang check
        # item['Summary_Rating_of_Prescription_Drug_Plan_Quality']=star[10]

        # item['Customer_Service_Rating']=	star[13]
        # item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability']=	star[24]	
        # item['Drug_Plan_Makes_Timely_Decisions_about_Appeals']=star[26]
        # item['Fairness_of_Drug_Plans_Appeal_Decisions']= star[28]
        
        # item['Member_Complaints_and_Changes']=star[16]
        # item['Complaints_about_the_Drug_Plan']=star[30]
        # item['Members_Choosing_to_Leave_the_Plan']=	star[32]

        # #########################################################################3
        # #2018, 2019
        # item['Improvement']=star[34]
        
        # item['Member_Experience_Rating']=star[19]
        # item['Members_Rating_of_Drug_Plan']= star[36]
        # item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan']=star[38]
        
        # item['Drug_Cost_Accuracy_Rating']= star[22]
        # item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy']=	star[40]
        # item['High_Risk_Medication']=star[42]
        # item['Medication_Adherence_for_Diabetes_Medications']=	star[44]
        # item['Medication_Adherence_for_Hypertension_RAS_antagonists']=	star[46]
        # item['Medication_Adherence_for_Cholesterol_Statins']=star[48]
        # item['MTM_Program_Completion_Rate_for_CMR']=	star[50]
        


        #########################################################################3
        # #2018 
        # #Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems)
        # item['Beneficiary_Access_and_Performance_Problems']=star[34]

        # item['Improvement']=star[36]
        
        # item['Member_Experience_Rating']=star[19]
        # item['Members_Rating_of_Drug_Plan']= star[38]
        # item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan']=star[40]
        
        # item['Drug_Cost_Accuracy_Rating']= star[22]
        # item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy']=	star[42]	
        # item['Medication_Adherence_for_Diabetes_Medications']=	star[44]
        # item['Medication_Adherence_for_Hypertension_RAS_antagonists']=	star[46]
        # item['Medication_Adherence_for_Cholesterol_Statins']=star[48]
        # item['MTM_Program_Completion_Rate_for_CMR']=	star[50]



        #########################################################################3
        #2019
        # item['Improvement']=star[34]
        
        # item['Member_Experience_Rating']=star[19]
        # item['Members_Rating_of_Drug_Plan']= star[36]
        # item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan']=star[38]
        
        # item['Drug_Cost_Accuracy_Rating']= star[22]
        # item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy']=	star[40]	
        # item['Medication_Adherence_for_Diabetes_Medications']=	star[42]
        # item['Medication_Adherence_for_Hypertension_RAS_antagonists']=	star[44]
        # item['Medication_Adherence_for_Cholesterol_Statins']=star[46]
        # item['MTM_Program_Completion_Rate_for_CMR']=	star[48]
        # item['Statin_Use_in_Persons_with_Diabetes']=star[50]

        #2019
        #year=2019
        # self.writer.writerow([year,item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Overall_Star_Rating'], item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan'], item['Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item['MTM_Program_Completion_Rate_for_CMR'], item['Statin_Use_in_Persons_with_Diabetes']])
        # yield{ 'Year':year,	'Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Overall_Star_Rating':item['Overall_Star_Rating'],'Summary_Rating_of_Prescription_Drug_Plan_Quality':'Summary_Rating_of_Prescription_Drug_Plan_Quality',	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions':item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR'],	'Statin Use in Persons with Diabetes':item['Statin_Use_in_Persons_with_Diabetes']}
        #########################################################################3
        #2018
        # year=2018
        # self.writer.writerow([year, item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Overall_Star_Rating'], item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan'],item['Beneficiary_Access_and_Performance_Problems'], item['Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item['MTM_Program_Completion_Rate_for_CMR']])
        # yield{'Year':year,	'Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Overall_Star_Rating':item['Overall_Star_Rating'],'Summary_Rating_of_Prescription_Drug_Plan_Quality':'Summary_Rating_of_Prescription_Drug_Plan_Quality',	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions':item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],'Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems)':item['Beneficiary_Access_and_Performance_Problems'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR']}


        # year=2017
        # self.writer.writerow([year, item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Overall_Star_Rating'], item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan'],item['Beneficiary_Access_and_Performance_Problems'], item['Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],item['High_Risk_Medication'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item['MTM_Program_Completion_Rate_for_CMR']])
        # yield{'Year':year,	'Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Overall_Star_Rating':item['Overall_Star_Rating'],'Summary_Rating_of_Prescription_Drug_Plan_Quality':'Summary_Rating_of_Prescription_Drug_Plan_Quality',	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions':item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],'Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems)':item['Beneficiary_Access_and_Performance_Problems'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],'High Risk Medication':item['High_Risk_Medication'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR']}

        year=2017
        self.writer.writerow([year, item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Overall_Star_Rating'], item['Summary_Rating_of_Prescription_Drug_Plan_Quality'], item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan'],item['Beneficiary_Access_and_Performance_Problems'], item['Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],item['High_Risk_Medication'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item['MTM_Program_Completion_Rate_for_CMR']])
        #yield{'Year':year,	'Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Overall_Star_Rating':item['Overall_Star_Rating'],'Summary_Rating_of_Prescription_Drug_Plan_Quality':item['Summary_Rating_of_Prescription_Drug_Plan_Quality'],	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions':item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],'Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems)':item['Beneficiary_Access_and_Performance_Problems'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],'High Risk Medication':item['High_Risk_Medication'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR']}


        yield item
        ########