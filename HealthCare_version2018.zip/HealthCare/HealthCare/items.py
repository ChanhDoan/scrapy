# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class HealthcareItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    #2019
    Plan_ID	= scrapy.Field()
    Plan_Name 	= scrapy.Field()	
    Organiztion_Marketing	= scrapy.Field()	
    State	= scrapy.Field()
    Type	= scrapy.Field()

    Plan_Type	= scrapy.Field()
    Monthly	= scrapy.Field()
    Annual	= scrapy.Field()
    Total_Drugs	= scrapy.Field()

    Tier_1	= scrapy.Field()
    Tier_2	= scrapy.Field()
    Tier_3	= scrapy.Field()
    Tier_4	= scrapy.Field()	
    Tier_5	= scrapy.Field()

    Number_Member	= scrapy.Field()
    Region	= scrapy.Field()
    Number_Member_CMS	= scrapy.Field()
    Number_Member_National	= scrapy.Field()

    Star_Rating		= scrapy.Field()
    Customer_Service_Rating		= scrapy.Field()
    Call_Center_Foreign_Language_Interpreter_and_TTY_Availability	= scrapy.Field()	
    
    Drug_Plan_Makes_Timely_Decisions_about_Appeals		= scrapy.Field()
    Fairness_of_Drug_Plans_Appeal_Decisions	= scrapy.Field()	
    
    Member_Complaints_and_Changes	= scrapy.Field()
    Complaints_about_the_Drug_Plan	= scrapy.Field()
    Members_Choosing_to_Leave_the_Plan	= scrapy.Field()
    #2018 
    #Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems)
    Beneficiary_Access_and_Performance_Problems= scrapy.Field()
    Improvement	= scrapy.Field()
    
    Member_Experience_Rating = scrapy.Field()
    Members_Rating_of_Drug_Plan = scrapy.Field()
    Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan = scrapy.Field()
    
    Drug_Cost_Accuracy_Rating = scrapy.Field()
    Medicare_gov_Plan_Finder_Drug_Price_Accuracy	= scrapy.Field()

    #2017 element
    High_Risk_Medication=scrapy.Field()	
    Medication_Adherence_for_Diabetes_Medications	= scrapy.Field()
    Medication_Adherence_for_Hypertension_RAS_antagonists	= scrapy.Field()
    Medication_Adherence_for_Cholesterol_Statins= scrapy.Field()
    MTM_Program_Completion_Rate_for_CMR	= scrapy.Field()
    Statin_Use_in_Persons_with_Diabetes = scrapy.Field()

    #2018
    # Plan_ID	
    # Plan_Name	
    # Organiztion Marketing	
    # State	
    # Type
    	
    # Plan_Type	
    # Monthly	
    # Annual	
    # Total_Drugs	

    # Tier 1	
    # Tier 2	
    # Tier 3	
    # Tier 4	
    # Tier 5	

    # Number_ Member	
    # Region	
    # Number_Member_CMS	
    # Number_ Member_National	

    # Star_Rating	
    # Customer_Service_Rating	
    # Call Center — Foreign Language Interpreter and TTY Availability	
    # Drug Plan Makes Timely Decisions about Appeals	

    # Fairness of Drug Plan’s Appeal Decisions	
    # Member Complaints and Changes	
    # Complaints about the Drug Plan (higher score is better - means fewer complaints)	
    # Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)	
    # Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems) [?]	
    # Improvement (if any) in the Drug Plan's Performance	

    # Member_Experience_Rating	
    # Members’s Rating of Drug Plan	
    # Ease of Getting Prescriptions Filled When Using the Plan	

    # Drug_Cost_Accuracy_Rating	
    # Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)	
    # Medication Adherence for Diabetes  Medications	
    # Medication Adherence for Hypertension (RAS antagonists)
    # Medication Adherence for Cholesterol (Statins)	
    # MTM Program Completion Rate for CMR

    #2017 
    # Plan_ID	
    # Plan_Name	
    # Organiztion Marketing	
    # State	
    # Type
    
    # Plan_Type	
    # Monthly	
    # Annual	
    # Total_Drugs	

    # Tier 1	
    # Tier 2	
    # Tier 3	
    # Tier 4	
    # Tier 5
    # 	
    # Number_ Member	
    # Region	
    # Number_Member_CMS	
    # Number_ Member_National	

    # Star_Rating	
    # Customer_Service_Rating	
    # Call Center — Foreign Language Interpreter and TTY Availability	
    # Drug Plan Makes Timely Decisions about Appeals	
    # Fairness of Drug Plan’s Appeal Decisions
    # 	
    # Member Complaints and Changes	
    # Complaints about the Drug Plan (higher score is better - means fewer complaints)	
    # Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)	
    # Beneficiary Access and Performance Problems (higher score is better - means fewer serious problems) [?]	
    # Improvement (if any) in the Drug Plan's Performance	

    # Member_Experience_Rating	
    # Members’s Rating of Drug Plan	
    # Ease of Getting Prescriptions Filled When Using the Plan	

    # Drug_Cost_Accuracy_Rating	
    # Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)
    # High Risk Medication	
    # Medication Adherence for Diabetes Medications	
    # Medication Adherence for Hypertension (RAS antagonists)	
    # Medication Adherence for Cholesterol (Statins)	
    # MTM Program Completion Rate for CMR