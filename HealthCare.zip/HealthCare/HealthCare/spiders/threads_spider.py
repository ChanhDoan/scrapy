import scrapy
import os
from bs4 import BeautifulSoup
import re
import urllib
from HealthCare.items import HealthcareItem


class ThreadsSpider(scrapy.Spider):
    
    name = "HealthCare"
    #start_urls = ['https://q1medicare.com/PartD-SearchPDPMedicare-2019PlanFinder.php#results',    ]
    start_urls=['https://q1medicare.com/PartD-SearchPDPMedicare-2019PlanFinder.php?state=AK#results',]
    #start_urls = ['https://q1medicare.com/PartD-2019-MedicarePDPDrugPlanBenefits.php?state=AK&source=2019PDPFinder&contractId=S4802&planId=165&plan=WellCare%20Value%20Script%20(PDP)%20-%20S4802-165&utm_source=partd&utm_medium=pdpfinder&utm_campaign=planname', ]
    
    #Get information state
    #start_urls = ['https://q1medicare.com/PartD-2019-MedicarePDPDrugPlanBenefits.php?state=CT&source=2019PDPFinder&contractId=S4802&planId=137&plan=WellCare%20Value%20Script%20(PDP)%20-%20S4802-137&utm_source=partd&utm_medium=pdpfinder&utm_campaign=planname', ]

    # list of Rating
    #start_urls = ['https://q1medicare.com/PartD-2019StarRatingsPartCPartDOverall.php?state=AK&contractId=S4802&planId=165&segmentId=0&countyCode=&showCounty=&plan=WellCare%20Value%20Script%20(PDP)&utm_medium=enrollRegChart&utm_campaign=startextlink',    ]


    #start_urls=['https://q1medicare.com/PartD-2019-MedicarePDPDrugPlanBenefits.php?state=CO&source=2019PDPFinder&contractId=S7126&planId=059&plan=Mutual%20of%20Omaha%20Rx%20Value%20(PDP)%20-%20S7126-059&utm_source=partd&utm_medium=pdpfinder&utm_campaign=planname', ]
    #start_urls = ['https://q1medicare.com/PartD-2019StarRatingsPartCPartDOverall.php?state=AK&contractId=S4802&planId=165&segmentId=0&countyCode=&showCounty=&plan=WellCare%20Value%20Script%20(PDP)&utm_medium=enrollRegChart&utm_campaign=startextlink',    ]
    def parse(self, response):
        
        urls=[]
        item=HealthcareItem()
        i=0
        for href in response.css('tr.tbldark a.teasertext::attr(href)').getall():
            if i%2==0:
                urls.append(href)
                #self.getInformation(href,row)
                print(i, href)
            i=i+1
        for href in response.css('tr.tbllight a.teasertext::attr(href)').getall():
            if i%2==0:
                urls.append(href)
                #self.getInformation(href,row)
                print(i, href)
            i=i+1
        for i in urls:
            request = scrapy.Request(i, callback=self.getInformation)
            request.meta['item'] = item #By calling .meta, we can pass our item object into the callback.
            yield request #Return the item + Rating back to the parser.
            print(item)
        
        print("\n\n")   
        #for quote in response.css('div.quote'):
        #    yield {
        #        'text': quote.css('span.text::text').get(),
        #        'author': quote.css('span small::text').get(),
        #        'tags': quote.css('div.tags a.tag::text').getall(),
        #    }

        #next_page = response.css('li.next a::attr(href)').get()
        #if next_page is not None:
        #    yield response.follow(next_page, callback=self.parse)
    
    #get list of link of State
    def getState(self, response):
        urls=[]
        for href in response.css('tr.tbldark a.teasertext::attr(href)').getall():
            urls.append(href)
        return urls

    #Information of each plan ID
    #Get information state
    #start_urls = ['https://q1medicare.com/PartD-2019-MedicarePDPDrugPlanBenefits.php?state=CT&source=2019PDPFinder&contractId=S4802&planId=137&plan=WellCare%20Value%20Script%20(PDP)%20-%20S4802-137&utm_source=partd&utm_medium=pdpfinder&utm_campaign=planname', ]
    def getInformation(self, response):

        ####################################################################
        
        # Tra ve gan du cac noi dung 
        item = response.meta['item']
        #item=HealthcareItem()
        resource=[]
        i=0
        for content in response.css('tr.tbllight td::text ').getall():
            print(i, content)
            i=i+1
            resource.append(content.strip())
        item['Plan_ID']=resource[3]
        item['Plan_Name']=resource[0].split("(PDP)")[0]
        Organiztion_Marketing=resource[1].split("by")
        item['Organiztion_Marketing']=Organiztion_Marketing[-1]
        item['State']=resource[2]
        type=resource[0].split(" ")[-1]
        type=type.strip(")")
        item['Type']=type.strip("(")

        item['Plan_Type']=resource[29]
        item['Monthly']=resource[7].split(" (see Plan Premium Details below)")[0]
        item['Annual']=resource[8].split(" (Tier 1 and 2  excluded from the Deductible.)")[0]
        item['Total_Drugs']=	resource[12].split(" drugs")[0]

        item['Tier_1']=resource[23]
        item['Tier_2']=resource[24]
        item['Tier_3']=resource[25]
        item['Tier_4']=resource[26]		
        item['Tier_5']=resource[27]	

        item['Number_Member']=resource[30].split("members")[0]	
        #row['Region']=resource[]
        item['Number_Member_CMS']=	resource[31].split("members")[0]	
        item['Number_Member_National']=	resource[33].split("members")[0]	

        

        
        #Click to see other plans
        #Browse the WellCare Value Script (PDP) Formulary
        #CMS Region 02
        region=[]
        for content in response.css('tr.tbllight td a.textred b::text ').getall():
            print(content)
            region.append(content.strip())
        item['Region']=region[2].split(" ")[-1]

        print("\n\n dong dang test ")
        for content in response.css('tr.tbllight td a.textred::text ').getall():
            print(content)
       
        # follow link rating 
        # kiem tra neu len=4 thi rating nay trong, khong cos link sang trang 
        link=[]
        for content in response.css('tr.tbllight td a.textred::attr(href) ').getall():
            print(content)
            link.append(content)
        
        if link.__len__()>4:
            next_url=link[4]
            #item = self.getStar(next_url)
            request = scrapy.Request(next_url, callback=self.getInformation)
            request.meta['item'] = item #By calling .meta, we can pass our item object into the callback.
            yield request #Return the item + Rating back to the parser.
            print(item)
        else:
            item['Star_Rating']=0
            item['Customer_Service_Rating']=	0
            item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability']=	0	
            
            item['Drug_Plan_Makes_Timely_Decisions_about_Appeals']=0
            item['Fairness_of_Drug_Plans_Appeal_Decisions']=		0
            item['Member_Complaints_and_Changes']=0
            
            item['Complaints_about_the_Drug_Plan']=0
            item['Members_Choosing_to_Leave_the_Plan']=	0
            item['Improvement']=0
            
            item['Member_Experience_Rating']=0
            item['Members_Rating_of_Drug_Plan']= 0
            item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan']=0
            
            item['Drug_Cost_Accuracy_Rating']= 0
            item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy']=	0	
            item['Medication_Adherence_for_Diabetes_Medications']=	0
            item['Medication_Adherence_for_Hypertension_RAS_antagonists']=	0
            item['Medication_Adherence_for_Cholesterol_Statins']=0
            item['MTM_Program_Completion_Rate_for_CMR']=	0
            item['Statin_Use_in_Persons_with_Diabetes']=0

        yield item
        ###################################################################

    # list of Rating
    #start_urls = ['https://q1medicare.com/PartD-2019StarRatingsPartCPartDOverall.php?state=AK&contractId=S4802&planId=165&segmentId=0&countyCode=&showCounty=&plan=WellCare%20Value%20Script%20(PDP)&utm_medium=enrollRegChart&utm_campaign=startextlink',    ]
    def getStar(self, response):
                
        ########
        item = response.meta['item']
        #item = HealthcareItem()
        star=[]
        content = response.css('tr.tblbluehdr th big::text').getall()
        
        star.append(content)
        #print(content)
        content=response.css('tr.tblbluehdr td b::text').getall()
        #print(content)
        
        star.append(content)

        for content in response.css('tr.tblhighlight td b::text ').getall():
            #print(content)
            star.append(content.strip())
        # list of star rating names
        #for content in response.css('tr td ul li::text ').getall():
        #    print(content)
        #print(response.css('tr td ul li::text ').getall())
        for content in response.css('tr.tblhighlightlight td b::text ').getall():
            #print(content)
            star.append(content.strip())
        for content in response.css('tr.tblnuetral td b::text ').getall():
            #print(content)
            star.append(content.strip())

        # list star rating 
        for content in response.css('tr.tbllight td::text ').getall():
            #print(content)
            star.append(content.strip())
        print("\n\n")
        count=0
        for i in star:
            print(count, i)
            count=count+1
        print("\n\n")
        
        item['Star_Rating']=star[10]
        
        item['Customer_Service_Rating']=	star[13]
        item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability']=	star[24]	
        item['Drug_Plan_Makes_Timely_Decisions_about_Appeals']=star[26]
        item['Fairness_of_Drug_Plans_Appeal_Decisions']= star[28]
        
        item['Member_Complaints_and_Changes']=star[16]
        item['Complaints_about_the_Drug_Plan']=star[30]
        item['Members_Choosing_to_Leave_the_Plan']=	star[32]
        item['Improvement']=star[34]
        
        item['Member_Experience_Rating']=star[19]
        item['Members_Rating_of_Drug_Plan']= star[36]
        item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan']=star[38]
        
        item['Drug_Cost_Accuracy_Rating']= star[22]
        item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy']=	star[40]	
        item['Medication_Adherence_for_Diabetes_Medications']=	star[42]
        item['Medication_Adherence_for_Hypertension_RAS_antagonists']=	star[44]
        item['Medication_Adherence_for_Cholesterol_Statins']=star[46]
        item['MTM_Program_Completion_Rate_for_CMR']=	star[48]
        item['Statin_Use_in_Persons_with_Diabetes']=star[50]

        yield item
        ########