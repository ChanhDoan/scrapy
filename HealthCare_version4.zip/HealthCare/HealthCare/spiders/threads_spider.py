import scrapy, csv
import os
from bs4 import BeautifulSoup
import re
import urllib
from HealthCare.items import HealthcareItem
from scrapy.crawler import CrawlerProcess


class ThreadsSpider(scrapy.Spider):
    
    name = "HealthCare"
    #start_urls = ['https://q1medicare.com/PartD-SearchPDPMedicare-2019PlanFinder.php#results',    ]
    start_urls=['https://q1medicare.com/PartD-SearchPDPMedicare-2019PlanFinder.php?utm_source=partd&utm_medium=jumplink&utm_campaign=header',]
    #start_urls=['https://q1medicare.com/PartD-SearchPDPMedicare-2019PlanFinder.php?state=CT#results', ]

    outfile = open("PlanID2019.csv", "w", newline="")
    writer = csv.writer(outfile)
    year=2019

    def parse(self, response):
        
        #i=0
        
        for href in response.css('div.w3-row span.text div a.textgroup::attr(href)').getall():
            # print(i, href)
            # i=i+1
            #item=HealthcareItem()
            yield scrapy.Request(href, callback=self.getState)
            
            
    def close(self):
        self.outfile.close()
        print("-----Check to see if this is closed-----")


    #get list of link of State
    def getState(self, response):
        
        urls=[]
        
        i=0
        for href in response.css('tr.tbldark a.teasertext::attr(href)').getall():
            if i%2==0:
                urls.append(href)
                #self.getInformation(href,row)
                #print(i, href)
            i=i+1
        for href in response.css('tr.tbllight a.teasertext::attr(href)').getall():
            if i%2==0:
                urls.append(href)
                #self.getInformation(href,row)
                #print(i, href)
            i=i+1
        for i in urls:
            yield scrapy.Request(i, callback=self.getInformation)
    

    #Information of each plan ID
    #Get information state
    #start_urls = ['https://q1medicare.com/PartD-2019-MedicarePDPDrugPlanBenefits.php?state=CT&source=2019PDPFinder&contractId=S4802&planId=137&plan=WellCare%20Value%20Script%20(PDP)%20-%20S4802-137&utm_source=partd&utm_medium=pdpfinder&utm_campaign=planname', ]
    def getInformation(self, response):

        ####################################################################
        
        # Tra ve gan du cac noi dung 
        #item = response.meta['item']
        item=HealthcareItem()
        resource=[]
        i=0
        for content in response.css('tr.tbllight td::text ').getall():
            #print(i, content)
            i=i+1
            resource.append(content.strip())
        item['Plan_ID']=resource[3]
        item['Plan_Name']=resource[0].split("(PDP)")[0]
        Organiztion_Marketing=resource[1].split("by")
        item['Organiztion_Marketing']=Organiztion_Marketing[-1]
        item['State']=resource[2]
        type=resource[0].split(" ")[-1]
        type=type.strip(")")
        item['Type']=type.strip("(")

        item['Plan_Type']=resource[29]
        item['Monthly']=resource[7].split(" (see Plan Premium Details below)")[0]
        item['Annual']=resource[8].split(" (Tier 1 and 2  excluded from the Deductible.)")[0]
        item['Total_Drugs']=	resource[12].split(" drugs")[0]

        item['Tier_1']=resource[23]
        item['Tier_2']=resource[24]
        item['Tier_3']=resource[25]
        item['Tier_4']=resource[26]		
        item['Tier_5']=resource[27]	
        if resource[31]==")":
            item['Number_Member']=0	
            #row['Region']=resource[]
            item['Number_Member_CMS']=	resource[30].split("members")[0]	
            item['Number_Member_National']=	resource[32].split("members")[0]
        else:
            item['Number_Member']=resource[30].split("members")[0]
            #row['Region']=resource[]
            item['Number_Member_CMS']=	resource[31].split("members")[0]	
            item['Number_Member_National']=	resource[33].split("members")[0]

        #Click to see other plans
        #Browse the WellCare Value Script (PDP) Formulary
        #CMS Region 02
        region=[]
        for content in response.css('tr.tbllight td a.textred b::text ').getall():
            #print(content)
            region.append(content.strip())
        item['Region']=region[2].split(" ")[-1]

        # print("\n\n dong dang test ")
        # for content in response.css('tr.tbllight td a.textred::text ').getall():
        #     print(content)
       
        # follow link rating 
        # kiem tra neu len=4 thi rating nay trong, khong cos link sang trang 
        link=[]

        for content in response.css('tr.tbllight td a.textred::attr(href) ').getall():
            #print(content)
            link.append(content)
        
        if link.__len__()>4:
            next_url=link[4]
            #item = self.getStar(next_url)
            request = scrapy.Request(next_url, callback=self.getStar)
            request.meta['item'] = item #By calling .meta, we can pass our item object into the callback.
            yield request #Return the item + Rating back to the parser.
            #print(item)
            self.writer.writerow([item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Star_Rating'], item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan'], item['Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item['MTM_Program_Completion_Rate_for_CMR'], item['Statin_Use_in_Persons_with_Diabetes']])
            yield{	'Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Star_Rating':item['Star_Rating'],	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions':item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR'],	'Statin Use in Persons with Diabetes':item['Statin_Use_in_Persons_with_Diabetes']}

        else:
            item['Star_Rating']=0
            item['Customer_Service_Rating']=	0
            item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability']=	0	
            
            item['Drug_Plan_Makes_Timely_Decisions_about_Appeals']=0
            item['Fairness_of_Drug_Plans_Appeal_Decisions']=		0
            item['Member_Complaints_and_Changes']=0
            
            item['Complaints_about_the_Drug_Plan']=0
            item['Members_Choosing_to_Leave_the_Plan']=	0
            item['Improvement']=0
            
            item['Member_Experience_Rating']=0
            item['Members_Rating_of_Drug_Plan']= 0
            item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan']=0
            
            item['Drug_Cost_Accuracy_Rating']= 0
            item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy']=	0	
            item['Medication_Adherence_for_Diabetes_Medications']=	0
            item['Medication_Adherence_for_Hypertension_RAS_antagonists']=	0
            item['Medication_Adherence_for_Cholesterol_Statins']=0
            item['MTM_Program_Completion_Rate_for_CMR']=	0
            item['Statin_Use_in_Persons_with_Diabetes']=0
            self.writer.writerow([item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Star_Rating'], item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan'], item['Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item['MTM_Program_Completion_Rate_for_CMR'], item['Statin_Use_in_Persons_with_Diabetes']])
            yield{	'Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Star_Rating':item['Star_Rating'],	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions':item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR'],	'Statin Use in Persons with Diabetes':item['Statin_Use_in_Persons_with_Diabetes']}

            yield item
        # self.writer.writerow([item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Star_Rating'], item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan, item.Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item[MTM_Program_Completion_Rate_for_CMR'], item['Statin_Use_in_Persons_with_Diabetes']])
        # yield{Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Star_Rating':item['Star_Rating'],	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions'::item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR'],	'Statin Use in Persons with Diabetes':item['Statin_Use_in_Persons_with_Diabetes']}
        #if item is None:
            #self.writer.writerow([item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Star_Rating'], item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan, item.Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item[MTM_Program_Completion_Rate_for_CMR'], item['Statin_Use_in_Persons_with_Diabetes']])
            #yield{'Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Star_Rating':item['Star_Rating'],	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions'::item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR'],	'Statin Use in Persons with Diabetes':item['Statin_Use_in_Persons_with_Diabetes']}

        # self.writer.writerow([item['Plan_ID'], item['Plan_Name'], item['Organiztion_Marketing'], item['State'], item['Type'], item['Plan_Type'], item['Monthly'], item['Annual'], item['Total_Drugs'], item['Tier_1'], item['Tier_2'], item['Tier_3'], item['Tier_4'], item['Tier_5'], item['Number_Member'],item['Region'], item['Number_Member_CMS'], item['Number_Member_National'], item['Star_Rating'], item['Customer_Service_Rating'], item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'], item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'], item['Fairness_of_Drug_Plans_Appeal_Decisions'], item['Member_Complaints_and_Changes'], item['Complaints_about_the_Drug_Plan'], item['Members_Choosing_to_Leave_the_Plan'], item['Improvement'], item['Member_Experience_Rating'], item['Members_Rating_of_Drug_Plan'], item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'], item['Drug_Cost_Accuracy_Rating'], item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'], item['Medication_Adherence_for_Diabetes_Medications'], item['Medication_Adherence_for_Hypertension_RAS_antagonists'], item['Medication_Adherence_for_Cholesterol_Statins'], item['MTM_Program_Completion_Rate_for_CMR'], item['Statin_Use_in_Persons_with_Diabetes']])
        # yield{	'Plan_ID':item['Plan_ID'],	'Plan_Name':item['Plan_Name'],	'Organiztion Marketing':item['Organiztion_Marketing'], 'State':item['State'],	'Type':item['Type'],	'Plan_Type':item['Plan_Type'],	'Monthly':item['Monthly'],	'Annual':item['Annual'],	'Total_Drugs':item['Total_Drugs'],	'Tier 1':item['Tier_1'], 'Tier 2':item['Tier_2'],	'Tier 3':item['Tier_3'],	'Tier 4':item['Tier_4'],	'Tier 5 ':item['Tier_5'],	'Number_ Member':item['Number_Member'], 'Region':item['Region'],'Number_Member_CMS':item['Number_Member_CMS'],	'Number_ Member_National':item['Number_Member_National'],	'Star_Rating':item['Star_Rating'],	'Customer_Service_Rating':item['Customer_Service_Rating'],	'Call Center — Foreign Language Interpreter and TTY Availability':item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability'],	'Drug Plan Makes Timely Decisions about Appeals':item['Drug_Plan_Makes_Timely_Decisions_about_Appeals'],	'Fairness of Drug Plan’s Appeal Decisions':item['Fairness_of_Drug_Plans_Appeal_Decisions'],	'Member Complaints and Changes':item['Member_Complaints_and_Changes'], 'Complaints about the Drug Plan (higher score is better - means fewer complaints)':item['Complaints_about_the_Drug_Plan'],	'Members Choosing to Leave the Plan (higher score is better - means fewer members leaving)':item['Members_Choosing_to_Leave_the_Plan'],	'Improvement (if any) in the Drug Plans Performance':item['Improvement'],	'Member_Experience_Rating':item['Member_Experience_Rating'],	'Members’s Rating of Drug Plan':item['Members_Rating_of_Drug_Plan'],	'Ease of Getting Prescriptions Filled When Using the Plan':item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan'],	'Drug_Cost_Accuracy_Rating':item['Drug_Cost_Accuracy_Rating'],	'Medicare,gov Plan Finder Drug Price Accuracy (higher score is better)':item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy'],	'Medication Adherence for Diabetes Medications':item['Medication_Adherence_for_Diabetes_Medications'],	'Medication Adherence for Hypertension (RAS antagonists)':item['Medication_Adherence_for_Hypertension_RAS_antagonists'],	'Medication Adherence for Cholesterol (Statins)':item['Medication_Adherence_for_Cholesterol_Statins'],	'MTM Program Completion Rate for CMR':item['MTM_Program_Completion_Rate_for_CMR'],	'Statin Use in Persons with Diabetes':item['Statin_Use_in_Persons_with_Diabetes']}
        
        ###################################################################

    # list of Rating
    #start_urls = ['https://q1medicare.com/PartD-2019StarRatingsPartCPartDOverall.php?state=AK&contractId=S4802&planId=165&segmentId=0&countyCode=&showCounty=&plan=WellCare%20Value%20Script%20(PDP)&utm_medium=enrollRegChart&utm_campaign=startextlink',    ]
    def getStar(self, response):
                
        ########
        item = response.meta['item']
        #item = HealthcareItem()
        star=[]

        content = response.css('tr.tblbluehdr th big::text').getall()
        star.append(content)
        #print(content)

        content=response.css('tr.tblbluehdr td b::text').getall()
        #print(content)
        star.append(content)

        for content in response.css('tr.tblhighlight td b::text ').getall():
            #print(content)
            star.append(content.strip())
        # list of star rating names
        #for content in response.css('tr td ul li::text ').getall():
        #    print(content)
        #print(response.css('tr td ul li::text ').getall())
        for content in response.css('tr.tblhighlightlight td b::text ').getall():
            #print(content)
            star.append(content.strip())
        for content in response.css('tr.tblnuetral td b::text ').getall():
            #print(content)
            star.append(content.strip())

        # list star rating 
        for content in response.css('tr.tbllight td::text ').getall():
            #print(content)
            star.append(content.strip())
        # print("\n\n")
        # count=0
        # for i in star:
        #     #print(count, i)
        #     count=count+1
        # print("\n\n")
        
        item['Star_Rating']=star[10]
        
        item['Customer_Service_Rating']=	star[13]
        item['Call_Center_Foreign_Language_Interpreter_and_TTY_Availability']=	star[24]	
        item['Drug_Plan_Makes_Timely_Decisions_about_Appeals']=star[26]
        item['Fairness_of_Drug_Plans_Appeal_Decisions']= star[28]
        
        item['Member_Complaints_and_Changes']=star[16]
        item['Complaints_about_the_Drug_Plan']=star[30]
        item['Members_Choosing_to_Leave_the_Plan']=	star[32]
        item['Improvement']=star[34]
        
        item['Member_Experience_Rating']=star[19]
        item['Members_Rating_of_Drug_Plan']= star[36]
        item['Ease_of_Getting_Prescriptions_Filled_When_Using_the_Plan']=star[38]
        
        item['Drug_Cost_Accuracy_Rating']= star[22]
        item['Medicare_gov_Plan_Finder_Drug_Price_Accuracy']=	star[40]	
        item['Medication_Adherence_for_Diabetes_Medications']=	star[42]
        item['Medication_Adherence_for_Hypertension_RAS_antagonists']=	star[44]
        item['Medication_Adherence_for_Cholesterol_Statins']=star[46]
        item['MTM_Program_Completion_Rate_for_CMR']=	star[48]
        item['Statin_Use_in_Persons_with_Diabetes']=star[50]

        yield item
        ########